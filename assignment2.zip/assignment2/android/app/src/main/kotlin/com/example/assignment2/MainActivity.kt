package com.example.assignment2

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
